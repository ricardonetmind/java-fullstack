$(function () {
    function omitirAcentos(text) {

        var acentos = "ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüû";
        var original = "AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuu";
        for (var i = 0; i < acentos.length; i++) {
            text = text.replace(acentos.charAt(i), original.charAt(i));
        }
        return text;
    }
    var palabras = ['camión', 'más', 'cáscaras', 'perdón', 'programación', 'tutú', 'desesperación', 'bígamo'];

    var palabra = palabras[Math.floor(Math.random() * palabras.length)];
    var palabrasin=omitirAcentos(palabra);
//En cadena guardaré los guiones y las letras acertadas.
    var cadena;

//Guardamos el número de fallos
    var fallos = 0;

//Al inicio será todo guiones bajos
    cadena = "_".repeat(palabra.length);

    pintarPalabra();
    pintarImagen();
    pintarTeclado();

    function pintarPalabra() {
        var c = cadena.split('').join(" ");

        $('#palabra').html("<h1>" + c + "</h1>");
        $('#palabra h1').hide().fadeIn(1000);
    }

    function pintarImagen() {
        $('#imagen img').hide();
        $('#imagen img').attr('src', 'elahorcado' + fallos + '.jpg');
        $('#imagen img').fadeIn(1000);
    }

    function pintarTeclado() {
        var teclado = "AEIOUBCDFGHJKLMNÑPQRSTVWXYZ";
        $('#teclado').html('');
        for (var i = 0; i < teclado.length; i++) {
            $('#teclado').append('<input type="button" class="btn btn-info" value="' + teclado.charAt(i) + '"> ');
        }
        $('.btn').click(function () {
            var letra = $(this).val().toLowerCase();
            var pos = palabrasin.indexOf(letra);
            if (pos === -1) {
                //No está la letra: aumento fallos, pinto imagen y compruebo si ha fallado 7 veces
                fallos++;
                pintarImagen();
                if (fallos >= 7) {
                    $('#teclado').html("<h2>HAS PERDIDO, LOOSER!!!</h2>");
                }
            } else {
                //Si está compruebo todas las apariciones de la letra y la muestro.
                do {
                    cadena = cadena.slice(0, pos) + palabra.charAt(pos) + cadena.slice(pos + 1);
                    pos = palabrasin.indexOf(letra, pos + 1);
                } while (pos >= 0);
                pintarPalabra();
                if (cadena === palabra) {
                    $('#teclado').html("<h2>HAS GANADO, CAMPEÓN!!!!</h2>");
                }
            }

            $(this).attr('disabled', 'disabled');
        }
        );

    }

});

